Example based on code from https://github.com/grpc/grpc/tree/master/examples/ruby/route_guide
