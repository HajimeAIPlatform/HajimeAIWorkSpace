# Attempt to import proto file, this should succeed
import path_with_dashes.demo_pb2
