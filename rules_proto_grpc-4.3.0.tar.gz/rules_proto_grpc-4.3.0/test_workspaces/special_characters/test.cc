#include "c d^*/demo.pb.h"

int main () {
    return demo().ByteSizeLong();
}
