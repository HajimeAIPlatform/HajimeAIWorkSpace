# Attempt to import proto file, this should succeed
import demo_pb2

# Attempt to import protobuf, this should succeed
import google.protobuf.timestamp_pb2

# Attempt to import grpc, this should succeed
import grpc
